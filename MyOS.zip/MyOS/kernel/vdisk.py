virtual_disk = {}
