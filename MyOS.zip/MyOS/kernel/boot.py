class boot:
    print("██       ██   █      █     ███████       ██████   1.0")
    print("█ █     █ █    █    █     █       █     █      ")
    print("█  █   █  █     █  █      █       █      █████ ")
    print("█   █ █   █      ██       █       █           █  ")
    print("█    █    █      ██        ███████       █████")
    print("Welcome to MyOS 1.0")