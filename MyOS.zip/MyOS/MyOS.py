from kernel import boot # the boot
from kernel import vdisk
disk = vdisk.virtual_disk
# ===============
# boot screen
bootScreen = boot.boot
bootScreen()
# ===============
# main
def main():
    print("Started OS. Type 'help' for a list of commands,\nand 'info' for information.")
    while True:
        user_input = input("MyOS >")
        if user_input == "hello":
            from _bin_ import hello
            hello.hello()
        elif user_input == "clear":
            from _bin_ import clear
            clear.clear()
        elif user_input.startswith("echo "):
            from _bin_ import echo
            echo.echo(user_input)
        elif user_input.startswith("ct "):
            from _bin_ import ct
            ct.ct(disk, user_input)
        elif user_input == "ls":
            from _bin_ import ls
            ls.ls(disk)
        elif user_input == "help":
            from _bin_ import help
            help.help()
        elif user_input.startswith("pt "):
            from _bin_ import pt
            pt.pt(user_input)
        elif user_input == "info":
            from _bin_ import info
            info.info()
        elif user_input == "exit":
            return
        elif user_input.startswith("dl "):
            from _bin_ import dl
            dl.dl(user_input, disk)
        elif not user_input:
            continue
        else:
            print("Dunno")


main()