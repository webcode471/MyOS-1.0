def pt(var):
    execute = var[3:]
    exec(execute)