def echo(self):
    print(self[5:])