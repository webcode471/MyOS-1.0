def ct(directory, inpt):
    file_name = inpt[3:]
    contents = input("Please enter its contents: ")
    try:
        directory[file_name] = contents
        print(f"Succesfully made file '{file_name}'.")
    except Exception as exception:
        print(f"Error: {exception}")