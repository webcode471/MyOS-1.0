def supriseme():
    import random
    chance = random.randint(1, 5)
    if chance == 1:
        print("Fun fact: Did you know baby snakes are more dangerous than adult snakes? Because they don't know how to control their venom, so they just spit all of it.")
    elif chance == 2:
        print("Fun fact: Did you know every old OS was written in Assembly, or C but then was compiled to Assembly?")
    elif chance == 3:
        print("Fun fact: Did you know the most used OS is Windows?")
    elif chance == 4:
        print("Fun fact: Did you know Linux is a very customizable OS with no needs of third-party software.")
    elif chance == 5:
        print("Fun fact: Did you know the most customizable unreleased OS was Windows Longhorn?")