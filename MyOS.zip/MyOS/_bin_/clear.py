def clear():
    try:
        import os
        os.system("cls")
    except Exception as e:        
        try:
            os.system("clear")
        except Exception as e:
            print(f"Error: {e}")