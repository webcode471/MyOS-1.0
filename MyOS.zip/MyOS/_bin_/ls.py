def ls(directory):
    for files, contents in directory.items():
        print(files + ": " + contents)
    if len(directory) == 0:
        print("Disk empty. Dunno what to say.")