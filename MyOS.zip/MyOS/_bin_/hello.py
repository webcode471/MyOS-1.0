def hello():
    print("Hi! The OS is currently breathing :)")
