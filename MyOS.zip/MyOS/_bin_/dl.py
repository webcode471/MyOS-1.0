def dl(var, direct):
    target = var[3:]
    try:
        del direct[target]
        print(f"Successfully deleted file '{target}'.")
    except KeyError:
        print(f"Error: file '{target}' not found.")
    except Exception as exception:
        print(f"Error: {exception}")